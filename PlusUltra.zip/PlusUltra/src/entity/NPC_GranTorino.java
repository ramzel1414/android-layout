package entity;

import java.awt.Rectangle;
import java.util.Random;

import main.GamePanel;

public class NPC_GranTorino extends Entity{

	
	public NPC_GranTorino(GamePanel gp) {
		
		super(gp);
		
		direction = "down";
		speed = 1;
		
		solidArea = new Rectangle();
		solidArea.x = 8;
		solidArea.y = 16;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width = 30;
		solidArea.height = 30;
		
		getImage();
		setDialogue();
	}
	public void getImage() { 	//player image
		
		up1 = setup("/npc/grantorino_up_1", gp.tileSize, gp.tileSize);
		up2 = setup("/npc/grantorino_up_2", gp.tileSize, gp.tileSize);
		down1 = setup("/npc/grantorino_down_1", gp.tileSize, gp.tileSize);
		down2 = setup("/npc/grantorino_down_2", gp.tileSize, gp.tileSize);
		left1 = setup("/npc/grantorino_left_1", gp.tileSize, gp.tileSize);
		left2 = setup("/npc/grantorino_left_2", gp.tileSize, gp.tileSize);
		right1 = setup("/npc/grantorino_right_1", gp.tileSize, gp.tileSize);
		right2 = setup("/npc/grantorino_right_2", gp.tileSize, gp.tileSize);
	}
	public void setDialogue() {
		
		dialogues[0] = "Deku! let me assist you.";
		dialogues[1] = "It seems that the Enemy successfully \ntrapped us in this ruins.";
		dialogues[2] = "His quirk is too powerful for me to handle \nhe got my one leg.";
		dialogues[3] = "I cannot use my Jet quirk yet,";
		
	}
	public void setAction() {		//npc behavior
		
		if(onPath == true) {
			
			int goalCol = (gp.player.worldX + gp.player.solidArea.x)/gp.tileSize;
			int goalRow = (gp.player.worldY + gp.player.solidArea.y)/gp.tileSize;
			
			searchPath(goalCol, goalRow);
		}
		
		else {
			
			actionLockCounter++;
			
			if(actionLockCounter == 120) {		//control movement to every 2 seconds
				
				Random random = new Random();
				
				int i = random.nextInt(100) + 1;	//picks random # 1=100
				
				if(i <= 25) {						//25% move up, down, right, and left
					direction = "up";
				}
				if(i > 25 && i <= 50) {
					direction = "down";
				}
				if(i > 50 && i <= 75) {
					direction = "left";
				}
				if(i > 75 && i <= 100) {
					direction = "right";
				}
				actionLockCounter = 0;
			}
		}
		
	}
	public void speak() {		//text in the window(dialogue)
		
		super.speak();
		
		
		onPath = true;
	}
}
