package entity;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.UtilityTool;
import object.OBJ_Gloves;

public class Entity {

	GamePanel gp;
	public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2, title, cursor, pause;
	public BufferedImage attackUp1, attackUp2, attackDown1, attackDown2, attackLeft1, attackLeft2, attackRight1, attackRight2;
	public BufferedImage image, image2, image3;
	public Rectangle solidArea = new Rectangle(0, 0, 48, 48);		//default solidArea for all ENTITYES (cant pass narrow paths)
	public Rectangle attackArea = new Rectangle(0, 0, 0, 0); 	//instantiating rectangle for player attack
	public int solidAreaDefaultX, solidAreaDefaultY;
	public boolean collisionOn = false;
	String dialogues[] = new String[20];
	public int hasKey;
	

	//STATE
	public int worldX, worldY;
	public String direction = "down";
	public int spriteNum = 1;
	int dialogueIndex = 0;
	public boolean collision = false;
	public boolean invincible = false;
	public boolean attacking = false;
	public boolean alive = true;
	public boolean dying = false;
	public boolean hpBarOn = false;
	public boolean onPath = false;
	public boolean knockBack = false;
	public boolean opened = false;
	
	//COUNTER
	public int spriteCounter = 0;
	public int invincibleCounter = 0;
	public int actionLockCounter;			//to slow down/control the move fps
	public int shotAvailableCounter = 0;
	public int dyingCounter = 0;
	public int hpBarCounter = 0;
	public int knockBackCounter = 0;
	
	//CHARACTER ATTRIBUTES
	public String name;
	public int defaultSpeed;
	public int speed;
	public int maxLife;
	public int life;
	public int level;
	public int dexterity;
	public int strength;
	public int attack;
	public int defense;
	public int exp;
	public int nextLevelExp;
	public int coin;
	public Entity currentWeapon;
	public Entity currentShield;
	public Entity currentLight;
	public Projectile projectile;
	
	//ITEM ATTRIBUTES
	public int value;
	public int attackValue;
	public String description = ""; 		//inventory
	public int knockBackPower = 0;
	public int lightRadius;
	
	
	//TYPE
	public int type;		//0-player, 1-npc, 2-monster	
	public final int type_player = 0;
	public final int type_npc =  1;
	public final int type_monster = 2;
	public final int type_fist = 3;
	public final int type_gloves = 4;
	public final int type_shield = 5;
	public final int type_consumable = 6;
	public final int type_pickupOnly = 7;
	public final int type_obstacle = 8;
	public final int type_light = 9;
	
	public Entity(GamePanel gp) {

		this.gp = gp;
	}
	//Getters for player solid AREA//
	public int getLeftX() {
		return worldX + solidArea.x;
	}
	public int getRightX() {
		return worldX + solidArea.x + solidArea.width;
	}
	public int getTopY() {
		return worldY + solidArea.y;
	}
	public int getBottomY() {
		return worldY + solidArea.y + solidArea.height;
	}
	public int getCol() {
		return (worldX + solidArea.x)/gp.tileSize;
	}
	public int getRow() {
		return (worldY + solidArea.y)/gp.tileSize;
	}
	public void resetCounter() {
		
		//COUNTER
		spriteCounter = 0;
		invincibleCounter = 0;
		actionLockCounter = 0;			//to slow down/control the move fps
		shotAvailableCounter = 0;
		dyingCounter = 0;
		hpBarCounter = 0;
		knockBackCounter = 0;
	}
	public void setAction() {	//set the entity's behavior
		
	}
	public void damageReaction() {		//monster reaction if get attacked
		
	}
	public void speak() {		//for dialogue
		
		if(dialogues[dialogueIndex] == null) {		//if theres no text , go back to 0 index
			dialogueIndex = 0;
		}
		
		gp.ui.currentDialogue = dialogues[dialogueIndex];
		dialogueIndex++;
		
		switch(gp.player.direction) {	//to make npc face player while talking
		case "up":direction = "down";break;
		case "down":direction = "up";break;
		case "left":direction = "right";break;
		case "right":direction = "left";break;
		
		}
	}
	public void interact() {	//for interacting objects
		
		
	}
	public boolean use(Entity entity) {return false;}		//in the kiss object, Every OBJECT to be consumed or pickup
	public void checkDrop() {			//check monster drop before it dies or set to null

	}
	public void dropItem(Entity droppedItem) {		//what item to drop (in this tutorial its random
		
		for(int i = 0; i < gp.obj[1].length; i++) {
			if(gp.obj[gp.currentMap][i] == null) {
				gp.obj[gp.currentMap][i] = droppedItem;			//if we found vacant slot we put the item
				gp.obj[gp.currentMap][i].worldX = worldX;			//death monsters world X and T(position dies)
				gp.obj[gp.currentMap][i].worldY = worldY;
				break;
			}
		}
	}
	//PARTICLES
	public Color getParticleColor() {	//	particle color
		Color color = null;	
		return color;
	}
	public int getParticleSize() {		//size
		int size = 0;	
		return size;
	}
	public int getParticleSpeed() {		//how fast
		int speed = 0;
		return speed;
	}
	public int getParticleMaxLife() {		//how long
		int maxLife = 0;
		return maxLife;
	}
	public void generateParticle(Entity generator, Entity target) {
		
		Color color = generator.getParticleColor();
		int size = generator.getParticleSize();
		int speed = generator.getParticleSpeed();
		int maxLife = generator.getParticleMaxLife();
		
		Particle p1 = new Particle(gp, target, color, size, speed, maxLife, -1, -1);
		Particle p2 = new Particle(gp, target, color, size, speed, maxLife, 1, -1);
		Particle p3 = new Particle(gp, target, color, size, speed, maxLife, -1, 1);
		Particle p4 = new Particle(gp, target, color, size, speed, maxLife, 1, 1);
		gp.particleList.add(p1);
		gp.particleList.add(p2);
		gp.particleList.add(p3);
		gp.particleList.add(p4);
		
	}
	public void checkCollision() {
		
		collisionOn = false;
		gp.cChecker.checkTile(this);
		gp.cChecker.checkObject(this, false);
		gp.cChecker.checkEntity(this, gp.npc);
		gp.cChecker.checkEntity(this, gp.monster);
		gp.cChecker.checkEntity(this, gp.iTile);
		boolean contactPlayer = gp.cChecker.checkPlayer(this);
		
		
		if(this.type == type_monster && contactPlayer == true) {
			damagePlayer(attack);
		}
	}
	public void update() {		//update the entity
		
		
		if(knockBack == true) {
			
			checkCollision();
			
			if(collisionOn == true) {
				knockBackCounter = 0;
				knockBack = false;
				speed = defaultSpeed;
			}
			else if(collisionOn == false) {
				switch(gp.player.direction) {
				case "up":worldY -= speed;break;
				case "down":worldY += speed;break;
				case "left":worldX -= speed;break;
				case "right":worldX += speed;break;
				}
			}
			
			knockBackCounter++;
			if(knockBackCounter == 10) {	//knockback distance
				knockBackCounter = 0;
				knockBack = false;
				speed = defaultSpeed;
			}
		}
		else {
			
			setAction();
			checkCollision();
			
			//IF COLLISIN IS FALSE ENTITY CAN MOVE
			if(collisionOn == false) {
				
				switch(direction) {
				case "up":worldY -= speed;break;
				case "down":worldY += speed;break;
				case "left":worldX -= speed;break;
				case "right":worldX += speed;break;
				}
			}
		}
		
		
		spriteCounter++;
		if(spriteCounter > 10) {		//chan7ging entity image
			if(spriteNum == 1) {
				spriteNum = 2;
			}
			else if(spriteNum == 2) {
				spriteNum = 1;
			}
			spriteCounter = 0;
		}
		
		if(invincible == true) {
			invincibleCounter++;
			if(invincibleCounter > 40) {
				invincible = false;
				invincibleCounter = 0;
			}
		}
		if(shotAvailableCounter < 30) {		//fixed, bug that throws 2x fireball at short distance
			shotAvailableCounter++;
		}
	}
	public void damagePlayer(int attack) {		//player got damaged
		
		if(gp.player.invincible == false) {		//we can give damage
			
			gp.playSE(8);
			
			int damage = attack - gp.player.defense;
			if(damage < 0) {
				damage = 0;
			}
			
			gp.player.life -= damage;
			gp.player.invincible = true;
			
		}
	}
	public void draw(Graphics2D g2) {
		
		BufferedImage image = null;
		int screenX = worldX - gp.player.worldX + gp.player.screenX;
		int screenY = worldY - gp.player.worldY + gp.player.screenY;
		
		if( worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && 
			worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
			worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
			worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
			
			switch(direction) {
			case "up":
				if(spriteNum == 1) {image = up1;}
				if(spriteNum == 2) {image = up2;}
				break;
			case "down":
				if(spriteNum == 1) {image = down1;}
				if(spriteNum == 2) {image = down2;}
				break;
			case "left":
				if(spriteNum == 1) {image = left1;}
				if(spriteNum == 2) {image = left2;}
				break;
			case "right":
				if(spriteNum == 1) {image = right1;}
				if(spriteNum == 2) {image = right2;}
				break;
			}
			
			//MONSTER HP BAR
			if(type == 2 && hpBarOn == true) {		//check if type mosnter
				
				double oneScale = (double)gp.tileSize/maxLife;		//hp bar length
				double hpBarValue = oneScale*life;
				
				g2.setColor(new Color(35,35,35));							//outline
				g2.fillRect(screenX-1, screenY-16, gp.tileSize+2, 12);
				
				g2.setColor(new Color(255, 0, 30));
				g2.fillRect(screenX, screenY-15, (int)hpBarValue, 10);
				
				hpBarCounter++;
				
				if(hpBarCounter > 600) {		//10 sec the hp bar disappear
					hpBarCounter = 0;
					hpBarOn = false;
				}
			}
			
			if(invincible == true) {	//opacity if player get damaged
				hpBarOn = true;
				hpBarCounter = 0;		//bar not disappear if keep attacking(idk if correct)
				changeAlpha(g2, 0.4f);
			}
			if(dying == true) {		//monster dying animation
				dyingAnimation(g2);
			}

			g2.drawImage(image, screenX, screenY, null);
		
			changeAlpha(g2, 1f);	
			}
	}
	public void dyingAnimation(Graphics2D g2) {	//dying animation for monster
		
		dyingCounter++;
		
		int i = 8;
		
		if(dyingCounter <= 5) {changeAlpha(g2,0f);}
		if(dyingCounter > i && dyingCounter <= i*2 ) {changeAlpha(g2,1f);}
		if(dyingCounter > i*2 && dyingCounter <= i*3 ) {changeAlpha(g2,1f);}
		if(dyingCounter > i*3 && dyingCounter <= i*4 ) {changeAlpha(g2,0f);}
		if(dyingCounter > i*4 && dyingCounter <= i*5 ) {changeAlpha(g2,1f);}
		if(dyingCounter > i*5 && dyingCounter <= i*6 ) {changeAlpha(g2,0f);}
		if(dyingCounter > i*8 && dyingCounter <= i*7 ) {changeAlpha(g2,1f);}
		if(dyingCounter > i*7 && dyingCounter <= i*8 ) {changeAlpha(g2,0f);}
		if(dyingCounter > i*8) {
			alive = false;
		}
	}
	public void changeAlpha(Graphics2D g2, float alphaValue) {		//blinking effect
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alphaValue));
	}
	public BufferedImage setup(String imagePath, int width, int height) {		//for optimization of image
		
		UtilityTool uTool = new UtilityTool();
		BufferedImage image = null;
		 
		try {
			image = ImageIO.read(getClass().getResourceAsStream(imagePath + ".png"));
			image = uTool.scaleImage(image, width, height);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		return image;
	}
	public void searchPath(int goalCol, int goalRow) {		//for PathFinding algorithm
		
		int startCol = (worldX + solidArea.x)/gp.tileSize;
		int startRow = (worldY + solidArea.y)/gp.tileSize;
		
		gp.pFinder.setNodes(startCol, startRow, goalCol, goalRow, this);
		
		if(gp.pFinder.search() == true) {
			
			//next worldX & worldY
			int nextX = gp.pFinder.pathList.get(0).col * gp.tileSize;
			int nextY = gp.pFinder.pathList.get(0).row * gp.tileSize;
		
			//entity's solidArea position
			int enLeftX = worldX + solidArea.x;
			int enRightX = worldX + solidArea.x + solidArea.width;
			int enTopY = worldY + solidArea.y;
			int enBottomY = worldY + solidArea.y + solidArea.height;
			
			if(enTopY > nextY && enLeftX >= nextX && enRightX < nextX + gp.tileSize) {
				direction = "up";
			}
			else if(enTopY < nextY && enLeftX >= nextX && enRightX < nextX + gp.tileSize) {
				direction = "down";
			}
			else if(enTopY >= nextY && enBottomY < nextY + gp.tileSize) {
				//left or right
				if(enLeftX > nextX) {
					direction = "left";
				}
				if(enLeftX < nextX) {
					direction = "right";
				}
			}
			else if(enTopY > nextY && enLeftX > nextX) {
				//up or left
				direction = "up";
				checkCollision();
				if(collisionOn == true) {
					direction = "left";
				}				
			}
			else if(enTopY > nextY && enLeftX < nextX) {
				//up or right
				direction = "up";
				checkCollision();
				if(collisionOn == true) {
					direction = "right";
				}
			}
			else if(enTopY < nextY && enLeftX > nextX) {		//maybe button?
				//down or left
				direction = "down";
				checkCollision();
				if(collisionOn == true) {
					direction = "left";
				}
			}
			else if(enTopY < nextY && enLeftX < nextX) {		//here also
				//down or right
				direction = "down";
				checkCollision();
				if(collisionOn == true) {
					direction = "right";
				}
			}
//			//if reaches the goal, stop the search
//			int nextCol = gp.pFinder.pathList.get(0).col;
//			int nextRow = gp.pFinder.pathList.get(0).row;
//			if(nextCol == goalCol && nextRow == goalRow) {
//				onPath = false;
//			}
			
		}
	}
	public int getDetected(Entity user, Entity target[][], String targetName) {
		
		int index = 999;
		
		//CHECK SORROUNDING OBJECT
		int nextWorldX = user.getLeftX();
		int nextWorldY = user.getTopY();
		
		switch(user.direction) { 	//if object is adjacent to the user it gets detected
		case "up": nextWorldY = user.getTopY()-gp.player.speed; break;
		case "down": nextWorldY = user.getBottomY()+gp.player.speed; break;
		case "left": nextWorldX = user.getLeftX()-gp.player.speed; break;
		case "right": nextWorldX = user.getRightX()+gp.player.speed; break;
		}
		int col = nextWorldX/gp.tileSize;
		int row = nextWorldY/gp.tileSize;
		
		for(int i = 0; i < target[1].length; i++) {
			if(target[gp.currentMap][i] != null) {
				if(target[gp.currentMap][i].getCol() == col &&
					target[gp.currentMap][i].getRow() == row &&
					target[gp.currentMap][i].name.equals(targetName)) {
						
					index = i;
					break;
				}
			}
		}
		return index;
	}

}
	
