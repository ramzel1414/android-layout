package entity;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import main.UtilityTool;
import object.OBJ_Bomb;
import object.OBJ_Door;
import object.OBJ_Energy;
import object.OBJ_Energy2;
import object.OBJ_Fist;
import object.OBJ_Gloves;
import object.OBJ_Key;
import object.OBJ_Kiss;

public class Player extends Entity{

	KeyHandler keyH;
	
	public final int screenX;
	public final int screenY;

	public boolean attackCanceled = false;
	public boolean lightUpdated = false;
	public ArrayList<Entity> inventory = new ArrayList<>();
	public final int maxInventorySize = 20;
	
	
	public Player(GamePanel gp, KeyHandler keyH) {
		
		super(gp);
		
		this.keyH = keyH;
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		solidArea = new Rectangle();		//area of player collision
		solidArea.x = 8;
		solidArea.y = 16;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width = 32;
		solidArea.height = 32;

		
		setDefaultValues();

	}
	
	public void setDefaultValues() {	

		worldX = gp.tileSize * 20;		//map deku1
		worldY = gp.tileSize * 28;
//		worldX = gp.tileSize * 15;		//map deku
//		worldY = gp.tileSize * 12;
//		worldX = gp.tileSize * 27;		//cars
//		worldY = gp.tileSize * 7;
		worldX = gp.tileSize * 24;		//map deku2
		worldY = gp.tileSize * 27;
		defaultSpeed = 4;
		speed = defaultSpeed;
		direction = "right";
		
		//PLAYER STATUS
		level = 1;
		maxLife = 6;
		life = maxLife;
		strength = 1;		//the more strength the more damage
		dexterity = 1;		//the more dexterity the less damage
		exp = 0;
		nextLevelExp = 5;
		coin = 0;
		currentWeapon = new OBJ_Fist(gp);
		projectile = new OBJ_Bomb(gp);
		currentLight = null;
		attack = getAttack();
		defense = getDefense();
		
		getPlayerImage();
		getAttackImage();
		setItem();
		
	}
	public void setDefaultPositions() {

//		gp.currentMap = 0;
		worldX = gp.tileSize * 15;
		worldY = gp.tileSize * 12;
		direction = "right";
	}
	public void restoreStatus() {
		
		life = maxLife;
		invincible = false;
		attacking = false;
		knockBack = false;
		lightUpdated = true;

	}
	public void setItem() {		//draw item in inventory	
		
		inventory.clear();
		inventory.add(currentWeapon);
		inventory.add(new OBJ_Energy(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));
//		inventory.add(new OBJ_Key(gp));

		
		inventory.add(new OBJ_Gloves(gp));
		
		//put an item if you want as default inventory

	}
	public int getAttack() {
		attackArea = currentWeapon.attackArea;
		return attack = strength;
	}
	public int getDefense() {
		return defense = dexterity;
	}
	public int getCurrentWeaponSlot() {
		int currentWeaponSlot = 0;
		for(int i=0; i< inventory.size(); i++) {
			if(inventory.get(i) == currentWeapon) {
				currentWeaponSlot = i;
			}
		}
		return currentWeaponSlot;
	}
	public void getPlayerImage() { 	//player image
		
		up1 = setup("/player/deku_up_1", gp.tileSize, gp.tileSize);
		up2 = setup("/player/deku_up_2", gp.tileSize, gp.tileSize);
		down1 = setup("/player/deku_down_1", gp.tileSize, gp.tileSize);
		down2 = setup("/player/deku_down_2", gp.tileSize, gp.tileSize);
		left1 = setup("/player/deku_left_1", gp.tileSize, gp.tileSize);
		left2 = setup("/player/deku_left_2", gp.tileSize, gp.tileSize);
		right1 = setup("/player/deku_right_1", gp.tileSize, gp.tileSize);
		right2 = setup("/player/deku_right_2", gp.tileSize, gp.tileSize);
		title = setup("/player/deku_title", gp.tileSize, gp.tileSize);
		cursor = setup("/player/deku_cursor", gp.tileSize, gp.tileSize);
		pause = setup("/player/deku_pause", gp.tileSize, gp.tileSize);
	}
	public void getAttackImage() {
		
		if(currentWeapon.type == type_gloves) {

			attackUp1 = setup("/player/gloves_up_1", gp.tileSize, gp.tileSize*2);
			attackUp2 = setup("/player/gloves_up_2", gp.tileSize, gp.tileSize*2);
			attackDown1 = setup("/player/gloves_down_1", gp.tileSize, gp.tileSize*2);
			attackDown2 = setup("/player/gloves_down_2", gp.tileSize, gp.tileSize*2);
			attackLeft1 = setup("/player/gloves_left_1", gp.tileSize*2, gp.tileSize);
			attackLeft2 = setup("/player/gloves_left_2", gp.tileSize*2, gp.tileSize);
			attackRight1 = setup("/player/gloves_right_1", gp.tileSize*2, gp.tileSize);
			attackRight2 = setup("/player/gloves_right_2", gp.tileSize*2, gp.tileSize);
			
		}
		else {
			
			attackUp1 = setup("/player/punch_up_1", gp.tileSize, gp.tileSize*2);
			attackUp2 = setup("/player/punch_up_2", gp.tileSize, gp.tileSize*2);
			attackDown1 = setup("/player/punch_down_1", gp.tileSize, gp.tileSize*2);
			attackDown2 = setup("/player/punch_down_2", gp.tileSize, gp.tileSize*2);
			attackLeft1 = setup("/player/punch_left_1", gp.tileSize*2, gp.tileSize);
			attackLeft2 = setup("/player/punch_left_2", gp.tileSize*2, gp.tileSize);
			attackRight1 = setup("/player/punch_right_1", gp.tileSize*2, gp.tileSize);
			attackRight2 = setup("/player/punch_right_2", gp.tileSize*2, gp.tileSize);
		}
	}
	public void update() {	//update player on the screen
		
		if(attacking == true) {
			attacking();
		}
		
		else if(keyH.upPressed == true || keyH.downPressed == true ||
				keyH.leftPressed == true || keyH.rightPressed == true ||
				keyH.enterPressed == true) {
			if(keyH.upPressed == true) {
				direction = "up";
			}
			else if(keyH.downPressed == true) {
				direction = "down";
			}
			else if(keyH.leftPressed == true) {
				direction = "left";
			}
			else if(keyH.rightPressed == true) {
				direction = "right";
			}
			//CHECK TILE COLLISION
			collisionOn = false;
			gp.cChecker.checkTile(this);
	
			
			//CHECK OBJECT COLLISION
			int objIndex = gp.cChecker.checkObject(this, true);
			pickUpObject(objIndex);
			
			//CHECK NPC COLLISION
			int npcIndex = gp.cChecker.checkEntity(this, gp.npc);
			interactNPC(npcIndex);
			
			//CHECK MONSTER COLLISSION
			int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
			contactMonster(monsterIndex);
			
			//CHECK COLLISION INTERACTIVE TILE
			gp.cChecker.checkEntity(this, gp.iTile);
			
			//CHECK EVENT
			gp.eHandler.checkEvent();
			
			//IF COLLISIN IS FALSE PLAYER CAN MOVE
			if(collisionOn == false && keyH.enterPressed == false) {
				
				switch(direction) {
				case "up":worldY -= speed;break;
				case "down":worldY += speed;break;
				case "left":worldX -= speed;break;
				case "right":worldX += speed;break;
				}
			}
			
			if(keyH.enterPressed == true && attackCanceled == false) {
				gp.playSE(14);
				attacking = true;
				spriteCounter = 0;
			}
			
			attackCanceled = false;
			gp.keyH.enterPressed = false;
			
			spriteCounter++;
			if(spriteCounter > 10) {		//chan7ging player image
				if(spriteNum == 1) {
					spriteNum = 2;
				}
				else if(spriteNum == 2) {
					spriteNum = 1;
				}
				spriteCounter = 0;
			}
		}
		//projectile
		if(gp.keyH.shotKeyPressed == true && projectile.alive == false && shotAvailableCounter == 30) {  	//cant shot if currentfireball is still alive
			
			//SET DEFAULT COORDINATEs, DIRECTION< USER
			projectile.set(worldX, worldY, direction, true, this);
			
			//CHECK VACANCY
			for(int i = 0; i < gp.projectile[1].length; i++) {		//check w/c slot is vacant and put this projectile to slot
				if(gp.projectile[gp.currentMap][i] == null) {
					gp.projectile[gp.currentMap][i] = projectile;
					break;
				}
			}
			
			shotAvailableCounter = 0;
			
			gp.playSE(20);
		}
		
		//needs to be outside of key if statement
		if(invincible == true) {
			invincibleCounter++;
			if(invincibleCounter > 60) {
				invincible = false;
				invincibleCounter = 0;
			}
		}
		//Projectile
		if(shotAvailableCounter < 30) {		//fixed, bug that throws 2x fireball at short distance
			shotAvailableCounter++;
		}
		//Items
		if(life > maxLife) {
			life = maxLife;
		}
		if(life <= 0) {
			gp.gameState = gp.gameOverState;
			gp.ui.commandNum = -1;	//cursor delay to avoid accident restart when dead
			gp.stopMusic();
			gp.playSE(6);		//BETTER CHANGE THIS LOL
		}
	}
	public void attacking() {	//when deku punch
		
		spriteCounter++;
		
		if(spriteCounter <= 5) {	//show the punch image 1 to 0-5frames
			spriteNum = 1;
		}
		if(spriteCounter > 5 && spriteCounter <= 25) {	//show punch 2 to 5 - 25 frames
			spriteNum = 2;
		
			//save the current worldX, worldY, solidArea
			int currentWorldX = worldX;
			int currentWorldY = worldY;
			int solidAreaWidth = solidArea.width;
			int solidAreaHeight = solidArea.height;
			
			//adjustplayers's worldX/Y for the attackArea
			switch(direction) {
			case "up": worldY -= attackArea.height; break;
			case "down": worldY += attackArea.height; break;
			case "left": worldX -= attackArea.width; break;
			case "right": worldX += attackArea.width; break;
			}

			//attack area becomes solid area
			solidArea.width = attackArea.width;
			solidArea.height = attackArea.height;
			
			//check monster collision with the updated worldX worldY and solidArea
			int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
			damageMonster(monsterIndex, attack, currentWeapon.knockBackPower);
			
			int iTileIndex = gp.cChecker.checkEntity(this, gp.iTile);
			damageInteractiveTile(iTileIndex);
	
			//Check if attack hitting projectile
			int projectileIndex = gp.cChecker.checkEntity(this,  gp.projectile);
			damageProjectile(projectileIndex);
			
			//after checking the collision, restore the original data
			worldX = currentWorldX;
			worldY = currentWorldY;
			solidArea.width = solidAreaWidth;
			solidArea.height = solidAreaHeight;

		}
		if(spriteCounter > 25) {
			spriteNum = 1;
			spriteCounter = 0;
			attacking = false;
		}
	}
	public void pickUpObject(int i) {	//object collision reaction
		
		if(i != 999) {
//			if(gp.obj[gp.currentMap][i].name == "Key") {		//solved key issue
//				hasKey++;										//maybe not , cause the number behind
//			}													//it shows negative if you use without door
			//PICKUP ONLY ITEMS
			if(gp.obj[gp.currentMap][i].type == type_pickupOnly) {
				
				gp.obj[gp.currentMap][i].use(this);
				gp.obj[gp.currentMap][i] = null;
			}
			//OBSTACLE
			else if(gp.obj[gp.currentMap][i].type == type_obstacle) {
				if(keyH.enterPressed == true) {
					attackCanceled = true;
					gp.obj[gp.currentMap][i].interact();
				}
			}
			else {
				
				//INVENTORY ITEMS
				String text;
				
				if(inventory.size() != maxInventorySize) { 	//if inventory not full
					
					inventory.add(gp.obj[gp.currentMap][i]);
					gp.playSE(3);
					text = "Got a " + gp.obj[gp.currentMap][i].name + "!";
				}
				else {
					text = "You cannot carry anymore!";
				}
				gp.ui.addMessage(text);
				gp.obj[gp.currentMap][i] = null;
			}
		}
	}
	public void interactNPC(int i) { 		//npc collision rection (press Enter perhaps?)
		
		if(gp.keyH.enterPressed == true) {
			
			if(i != 999) {						//means player touching npc
				
				attackCanceled = true;
				gp.gameState = gp.dialogueState;
				gp.npc[gp.currentMap][i].speak();
			}
			
		}
	}
	public void contactMonster(int i) {		//player receive damage if contact w/ monster
		
		if(i != 999) {
			
			if(invincible == false && gp.monster[gp.currentMap][i].dying == false) {
				gp.playSE(8);
				
				int damage = gp.monster[gp.currentMap][i].attack = defense;
				if(damage < 0) {
					damage = 0;
				}
				life -= damage;
				invincible = true;
			}
		}
	}
	public void damageMonster(int i, int attack, int knockBackPower) {		//when monster get hit
		
		if(i != 999) {
			
			if(gp.monster[gp.currentMap][i].invincible == false) {
				
				gp.playSE(15);
				
				if(knockBackPower > 0) {
					knockBack(gp.monster[gp.currentMap][i], knockBackPower);	//monster that we are hitting
				}
				
				int damage = attack - gp.monster[gp.currentMap][i].defense;
				if(damage < 0) {	
					damage = 0;
				}
				
				gp.monster[gp.currentMap][i].life -= damage;
				gp.ui.addMessage(damage + " damage!");
				
				gp.monster[gp.currentMap][i].invincible = true;
				gp.monster[gp.currentMap][i].damageReaction();
				
				if(gp.monster[gp.currentMap][i].life <= 0) {		//kill the monster
					gp.monster[gp.currentMap][i].dying = true;
					gp.ui.addMessage("Deku killed " + gp.monster[gp.currentMap][i].name + "!");
					gp.ui.addMessage("Deku Exp " + gp.monster[gp.currentMap][i].exp);
					exp += gp.monster[gp.currentMap][i].exp;
					checkLevelUp();
					
				}
			}
		}
	}
	public void knockBack(Entity entity, int knockBackPower) {	//knockBack Effect
		
		entity.direction = direction;
		entity.speed += knockBackPower;
		entity.knockBack = true;
	}
	public void damageInteractiveTile(int i) {			//to damage destructible tile
		
		
		if(i != 999 && gp.iTile[gp.currentMap][i].destructible == true &&
				gp.iTile[gp.currentMap][i].isCorrectItem(this) == true &&
				gp.iTile[gp.currentMap][i].invincible == false) {

			gp.iTile[gp.currentMap][i].setAction();
			gp.iTile[gp.currentMap][i].damageReaction();
			gp.iTile[gp.currentMap][i].playSE();
			gp.iTile[gp.currentMap][i].life--;
			gp.iTile[gp.currentMap][i].invincible = true;
			
			generateParticle(gp.iTile[gp.currentMap][i], gp.iTile[gp.currentMap][i]);
			
			if(gp.iTile[gp.currentMap][i].life == 0) {
				gp.iTile[gp.currentMap][i] = null;
			}
		}
	}
	public void damageProjectile(int i) {	//if hitting the projectile
		
		if(i != 999) {
			Entity projectile = gp.projectile[gp.currentMap][i];
			projectile.alive = false;
			generateParticle(projectile, projectile);
		}
	}
	public void checkLevelUp() {		//check if player level up
		
		if(exp >= nextLevelExp) {
			
			level++;
			nextLevelExp = nextLevelExp*2;
			maxLife += 2;
			strength++;
			dexterity++;
			attack = getAttack();
			defense = getDefense();
			
			gp.playSE(17);
			gp.gameState = gp.dialogueState;
			gp.ui.currentDialogue = "Deku is now level " + level + "!";
		}
	}
	public void selectItem() {		//selecting item in inventory
		
		int itemIndex = gp.ui.getItemIndexOnSlot();
		
		if(itemIndex < inventory.size()) {		//selecting an item
			
			Entity selectedItem = inventory.get(itemIndex);
			
			if(selectedItem.type == type_fist || selectedItem.type == type_gloves) {	//to change between weapons
				currentWeapon = selectedItem;
				attack = getAttack();
				getAttackImage();
			}
			if(selectedItem.type == type_light) {		//selecting light type
				
				if(currentLight == selectedItem) {
					currentLight = null;
				}
				else {
					currentLight = selectedItem;
				}
				lightUpdated = true;
			}
			if(selectedItem.type == type_consumable) {		//selecteing consumable type
				if(selectedItem.use(this) == true) {		
					inventory.remove(itemIndex); 
				}
			}
//			if(selectedItem.name == "Key") {		//solved key issue
//			hasKey--;								//also there's an error popping out about array out of bounsd in draing inventory	
//			}										//I dont wanna get an error while demonstrating my game this December 5. 2022
		}
	}
	public void draw(Graphics2D g2) {	//draw player on the screen
		
		BufferedImage image = null;
		int tempScreenX = screenX;
		int tempScreenY = screenY;
		switch(direction) {
		case "up":
			if(attacking == false) {
				if(spriteNum == 1) {image = up1;}
				if(spriteNum == 2) {image = up2;}
			}
			if(attacking == true) {
				tempScreenY = screenY - gp.tileSize;
				if(spriteNum == 1) {image = attackUp1;}
				if(spriteNum == 2) {image = attackUp2;}
			}
			break;
		case "down":
			if(attacking == false) {
				if(spriteNum == 1) {image = down1;}
				if(spriteNum == 2) {image = down2;}
			}
			if(attacking == true) {
				if(spriteNum == 1) {image = attackDown1;}
				if(spriteNum == 2) {image = attackDown2;}
			}
			break;
		case "left":
			if(attacking == false) {
				if(spriteNum == 1) {image = left1;}
				if(spriteNum == 2) {image = left2;}
			}
			if(attacking == true) {
				tempScreenX = screenX - gp.tileSize;
				if(spriteNum == 1) {image = attackLeft1;}
				if(spriteNum == 2) {image = attackLeft2;}
			}
			break;
		case "right":
			if(attacking == false) {
				if(spriteNum == 1) {image = right1;}
				if(spriteNum == 2) {image = right2;}
			}
			if(attacking == true) {
				if(spriteNum == 1) {image = attackRight1;}
				if(spriteNum == 2) {image = attackRight2;}
			}
			break;
		
		}
		
		if(invincible == true) {	//opacity if player get damaged
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		}
		
		g2.drawImage(image, tempScreenX, tempScreenY, null);
		
		//reset alpha
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
	}
}




