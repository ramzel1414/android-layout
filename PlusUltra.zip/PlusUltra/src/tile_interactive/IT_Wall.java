package tile_interactive;

import java.awt.Color;

import entity.Entity;
import main.GamePanel;

public class IT_Wall extends InteractiveTile{
	
	GamePanel gp;

	public IT_Wall(GamePanel gp, int col, int row) {
		super(gp, row, row);
		this.gp = gp;
		
		this.worldX = gp.tileSize * col;
		this.worldY = gp.tileSize * row;
		
		down1 = setup("/tile_interactive/wall2", gp.tileSize, gp.tileSize);
		destructible = true;
		life = 3;
	}
	public boolean isCorrectItem(Entity entity) {	//destroy with certail weapon only
		boolean isCorrectItem = false;
		
		if(entity.currentWeapon.type == type_gloves) {
			isCorrectItem = true;
		}
		
		
		return isCorrectItem;
	}
	public void playSE() {
		gp.playSE(13);
	}
	
	//ACTIVATE THIS METHOD IF YOU WANT MONSTER TO BE ELUSIVE(MAILAP)
	//galagpot kung sumbagon LOL
	public void damageReaction() {	//mosnter reaction when get attacked
		
		actionLockCounter = 0;
		direction = gp.player.direction;	//move away to the direction where it gets hit
		speed += 2;
	}
	
	//PARTICLES
	public Color getParticleColor() {	//	particle color
		Color color = new Color(0, 0, 0);	
		return color;
	}
	public int getParticleSize() {		//size
		int size = 6; // 6 pixels	
		return size;
	}
	public int getParticleSpeed() {		//how fast
		int speed = 1;
		return speed;
	}
	public int getParticleMaxLife() {		//how long
		int maxLife = 20;
		return maxLife;
	}
	
}
