package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;
import java.util.ArrayList;

import entity.Entity;
import object.OBJ_Heart;
import object.OBJ_Key;

public class UI {
	
	GamePanel gp;
	Graphics2D g2;
	Font arial_40;
	BufferedImage keyImage, heart_full, heart_half, heart_blank;
	public boolean messageOn = false;
	ArrayList<String> message = new ArrayList<>();
	ArrayList<Integer> messageCounter = new ArrayList<>();
	public boolean gameFinished = false;
	public String currentDialogue = "";
	public int commandNum = 0;						//cursor for title screen
	public int commandNumH = 0;						//cursor inside "how to play" (back)
	public int titleScreenState = 0;			// 0 - first screen, 1 - second screen
	public int slotCol = 0;
	public int slotRow = 0;
	int subState = 0;
	int counter = 0;
	
	
	public UI(GamePanel gp) {
		this.gp = gp;
		
		arial_40 = new Font("Arial", Font.PLAIN, 40);
		OBJ_Key key = new OBJ_Key(gp);					//instantiating  keyImage to display on screen
		keyImage = key.image;
		
		
		//CREATE AUD OBJECT
		Entity heart = new OBJ_Heart(gp);			//instantiating heartImages to display on screen
		heart_full = heart.image;						
		heart_half = heart.image2;
		heart_blank = heart.image3;
		
		
	}
	public void addMessage(String text) {		//store message to display on screen
		
		message.add(text);
		messageCounter.add(0);
	}
	public void draw(Graphics2D g2) {	//draw on screen (eg. text, object)
		
		this.g2 = g2;
		g2.setFont(arial_40);				//default font on the screen			
		g2.setColor(Color.white);			//default color on the screen
		
//		g2.drawImage(keyImage, gp.tileSize*14-25, gp.tileSize*11, null);			//Key Image position when frame X in character screen is still /2 and maxScreenCol is still 16
//		g2.drawImage(keyImage, gp.tileSize*18-25, gp.tileSize*11, null);			//Key Image position
//		g2.drawString("= " + gp.player.hasKey, gp.tileSize*19-20, gp.tileSize*11+37);//gonna comment this out, 
		
		//title state
		if(gp.gameState == gp.titleState) {
			drawTitleScreen();
		}
		
		//play state
		if(gp.gameState == gp.playState) {
		
			drawPlayerLife();
			drawMessage();
		}
		//pause state
		if(gp.gameState == gp.pauseState) {
			drawPauseScreen();
			drawPlayerLife();
		}
		//dialogue state
		if(gp.gameState == gp.dialogueState) {
			drawDialogueScreen();
			drawPlayerLife();
		}
		//character state
		if(gp.gameState == gp.characterState) {
			drawCharacterScreen();
			drawInventory();
		}
		//option state
		if(gp.gameState == gp.optionState) {
			drawOptionScreen();
		}
		//gameover state
		if(gp.gameState == gp.gameOverState) {
			drawGameOverScreen();
		}
		//transition state
		if(gp.gameState == gp.transitionState) {
			drawTransition();
		}
		//level state
		if(gp.gameState == gp.levelState) {
			drawLevelStateScreen();
		}
		//victory state
		if(gp.gameState == gp.victoryState) {
			drawVictoryStateScreen();
			gp.stopMusic();
		}
	}
	public void drawPlayerLife() {		//draw heart image
		
//		gp.player.life = 6;
		
		int x = gp.tileSize*0;		//horizontal position
		int y = gp.tileSize*11;		//vertical position
		int i = 0;					
		
		
		while(i < gp.player.maxLife/2) {	//actual drawing of heart(BLANK)
			g2.drawImage(heart_blank, x, y, null);
			i++;
			x += gp.tileSize;
		}
		x = gp.tileSize*0;		//horizontal position
		y = gp.tileSize*11;		//vertical position
		i = 0;
		
		while(i < gp.player.life) {			//then	cover with a heart(HALF)
			g2.drawImage(heart_half, x, y, null);
			i++;
			if(i < gp.player.life) {		//lastly cover with a heart(FULL)
				g2.drawImage(heart_full, x, y, null);
			}
			i++;
			x += gp.tileSize;
		}
	}
	public void drawMessage() {			//draw message on screen
		
		int messageX = gp.tileSize/2;
		int messageY = gp.tileSize;
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));
		
		for(int i = 0; i < message.size(); i++) {
			
			if(message.get(i) != null) {	//check if theres message in array
				
				g2.setColor(Color.white);	//shadow
				g2.drawString(message.get(i), messageX+1, messageY+1);
				
				g2.setColor(Color.green);
				g2.drawString(message.get(i), messageX, messageY);
				
				int counter = messageCounter.get(i) + 1;		//messageCounter++
				messageCounter.set(i, counter);				//setthe counter to the array
				messageY += 35;			//to display next message on screen
				
				if(messageCounter.get(i) > 120) {		//3 seconds
					message.remove(i);
					messageCounter.remove(i);
				}
				
			}
		}
	}
	public void drawTitleScreen() {		//title screen
		
		
		if(titleScreenState == 0) {		//check if first screen (I created this for not for the character classification byt for the how to play option
			
			g2.setColor(Color.black);		//backGround
			g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
			
			
			//title name
			g2.setFont(g2.getFont().deriveFont(Font.BOLD, 100));
			String text = "PLUS ULTRA";
			int x = getXForCenteredText(text);
			int y = gp.tileSize * 3;
			
			//shadow
			g2.setColor(Color.white);
			g2.drawString(text, x+5, y+5);
			
			//Main color
			g2.setColor(Color.green);
			g2.drawString(text, x, y);
			
			//deku image
			x = gp.screenWidth/2 - (gp.tileSize*2)/2;
			y += gp.tileSize * 2;
			g2.drawImage(gp.player.title, x, y, gp.tileSize*2, gp.tileSize*2, null);		
			
			
			g2.setFont(g2.getFont().deriveFont(Font.BOLD, 30));			//overriding font	
			
			text = "NEW GAME";
			x = getXForCenteredText(text);
			y += gp.tileSize * 3.5;
			g2.drawString(text, x, y);
			if(commandNum == 0) {
				g2.drawImage(gp.player.cursor, x-gp.tileSize, y-30, null);			//I made this cursor! (proud)
			}
			
			text = "LOAD GAME";
			x = getXForCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text, x, y);
			if(commandNum == 1) {
				g2.drawImage(gp.player.cursor, x-gp.tileSize, y-30, null);
			}
			
			text = "HOW TO PLAY";
			x = getXForCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text, x, y);
			if(commandNum == 2) {
				g2.drawImage(gp.player.cursor, x-gp.tileSize, y-30, null);
			}
			
			text = "QUIT";
			x = getXForCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text, x, y);
			if(commandNum == 3) {
				g2.drawImage(gp.player.cursor, x-gp.tileSize, y-30, null);
			}
		}
		else if(titleScreenState == 1) {	//tp draw in How to play , I really struggled here, to go back to main menu / TITLE STATE
			
			g2.setColor(Color.black);		//backGround
			g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
			
			g2.setColor(Color.green);
			g2.setFont(g2.getFont().deriveFont(30F));
			
			String text = "Find the hidden keys inside the ruins to unlock the doors.";
			int x = getXForCenteredText(text);
			int y = gp.tileSize*3;
			g2.drawString(text, x, y);
			
			text = "Back";
			x = getXForCenteredText(text);
			y += gp.tileSize * 8;
			g2.drawString(text, x, y);
			if(commandNumH == 0) {
				g2.drawImage(gp.player.cursor, x-gp.tileSize, y-30, null);			//I made this cursor! (proud)
			}
		}
	}
	
	
	public void drawPauseScreen() {		//pause on screen
			
		//pause image from player 			//scaled and created by me
		int x = gp.tileSize*4;
		int y = gp.tileSize;
		g2.drawImage(gp.player.pause, x, y, gp.tileSize*12, gp.tileSize*10, null);	
	}
	public void drawCharacterScreen() {
		
		//CREATE A FRAME
		final int frameX = gp.tileSize*2;			//horizontal position of frame
		final int frameY = gp.tileSize/2;			//vertical
		final int frameWidth = gp.tileSize * 5;		//width
		final int frameHeight = gp.tileSize * 7;	//height
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		//TEXT
		g2.setColor(Color.green);
		g2.setFont(g2.getFont().deriveFont(20F));		//font size
		
		int textX = frameX + 20;			//left margin
		int textY = frameY + gp.tileSize;	//up bottom margin
		final int lineHeight = 35;			//spacing 
		
		g2.drawString("Life", textX, textY);
		textY += lineHeight;
		g2.drawString("Level", textX, textY);
		textY += lineHeight;
		g2.drawString("Strength", textX, textY);
		textY += lineHeight;
		g2.drawString("Dexterity", textX, textY);
		textY += lineHeight;
		g2.drawString("Attack", textX, textY);
		textY += lineHeight;
		g2.drawString("Defense", textX, textY);
		textY += lineHeight;
		g2.drawString("Exp", textX, textY);
		textY += lineHeight;
		g2.drawString("NextLevel", textX, textY);
		textY += lineHeight;
		
		//VALUES
		int tailX = (frameX + frameWidth) - 30;
		//RESET TEXT Y
		textY = frameY + gp.tileSize;
		String value;
		
		value = String.valueOf(gp.player.life + "/" + gp.player.maxLife);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.level);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		
		value = String.valueOf(gp.player.strength);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.dexterity);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.attack);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.defense);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.exp);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.nextLevelExp);
		textX = getXForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
	}
	public void drawInventory() {	//draw inventory
		
		//FRAME
		int frameX = gp.tileSize*12;
		int frameY = gp.tileSize/2;
		int frameWidth = gp.tileSize*6;
		int frameHeight = gp.tileSize*5;
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		//SLOT
		final int slotXstart = frameX + 20;
		final int slotYstart = frameY + 20;
		int slotX = slotXstart;
		int slotY = slotYstart;
		int slotSize = gp.tileSize + 3;			//adjust the little space on sides
		
		//DRAW PLAYER's ITEMS
		for(int i = 0; i < gp.player.inventory.size(); i++) {
			
			//EQUIP CURSOR
			if(gp.player.inventory.get(i) == gp.player.currentWeapon ||
					gp.player.inventory.get(i) == gp.player.currentShield ||
					gp.player.inventory.get(i) == gp.player.currentLight) {			//equipable Item.(permanent in inventory)
				g2.setColor(new Color(240, 190, 90));
				g2.fillRoundRect(slotX, slotY, gp.tileSize, gp.tileSize, 10, 10);
			}
			
			g2.drawImage(gp.player.inventory.get(i).down1, slotX, slotY, null);			//causing error
			
			
			
			slotX += slotSize;
			
			if(i == 4 || i == 9 || i == 14) {  //next row
				slotX = slotXstart;
				slotY += slotSize;
			}
		}
		
		//CURSOR
		int cursorX = slotXstart + (slotSize * slotCol);
		int cursorY = slotYstart + (slotSize * slotRow);
		int cursorWidth = gp.tileSize;
		int cursorHeight = gp.tileSize;
		
		//DRAW CURSOR
		g2.setColor(Color.green);
		g2.setStroke(new BasicStroke(3));		//thickness of cursor (border)
		g2.drawRoundRect(cursorX, cursorY, cursorWidth, cursorHeight, 10, 10);
		
		//DESCRIPTION FRAME
		int dFrameX = frameX;
		int dFrameY = frameY + frameHeight;
		int dFrameWidth = frameWidth;
		int dFrameHeight = gp.tileSize*3;
		//DRAW DESCRIPTION TEXT
		int textX = dFrameX + 20;
		int textY = dFrameY + gp.tileSize;
		g2.setFont(g2.getFont().deriveFont(20F));
		g2.setColor(Color.green);
		
		int itemIndex = getItemIndexOnSlot();
		
		if(itemIndex < gp.player.inventory.size()) {

			drawSubWindow(dFrameX, dFrameY, dFrameWidth, dFrameHeight);
			
			for(String line: gp.player.inventory.get(itemIndex).description.split("\n")) {		//to make \n function	//this line is the issue I mean on playerclass
				g2.drawString(line, textX, textY);
				textY += 32;
			}
		}
	}
	public int getItemIndexOnSlot() { // inventory
		int itemIndex = slotCol + (slotRow*5);
		return itemIndex;
	}
	public void drawGameOverScreen() {
		
		g2.setColor(new Color(0, 0, 0, 150));	//BackGround
		g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
		
		int x;
		int y;
		String text;
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 110f));
		
		//shadow
		text = "Game Over";
		g2.setColor(Color.white);
		x = getXForCenteredText(text);
		y = gp.tileSize*4;
		g2.drawString(text,  x,  y);
		
		//main
		g2.setColor(Color.green);
		g2.drawString(text, x-4, y-4);
		
		//Retry
		g2.setFont(g2.getFont().deriveFont(50f));
		text = "Retry";
		x = getXForCenteredText(text);
		y += gp.tileSize*4;
		g2.drawString(text, x, y);
		if(commandNum == 0) {
			g2.drawImage(gp.player.cursor, 350, 345, 50, 50, null);			//calculated coordiantes by me LOL
		}
		//back to the title screen
		text = "Quit";
		x = getXForCenteredText(text);
		y += 65;
		g2.drawString(text, x, y);
		if(commandNum == 1) {
			g2.drawImage(gp.player.cursor, 365, 410, 50, 50, null);
		}
	}
	
	
	//OPTION SCREEN
	
	public void drawOptionScreen() {
		
		g2.setColor(Color.white);
		g2.setFont(g2.getFont().deriveFont(30F));
		
		//sub window
		int frameX = gp.tileSize*6;				//6
		int frameY = gp.tileSize;
		int frameWidth = gp.tileSize*8;			//8
		int frameHeight = gp.tileSize*10;
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		switch(subState) {			//options
		case 0: option_top(frameX, frameY); break;
		case 1: option_fullScreenModification(frameX, frameY); break;
		case 2: options_control(frameX, frameY); break;
		case 3: options_endGameConfirmation(frameX, frameY); break;
		}
		
		gp.keyH.enterPressed = false;
	}
	public void option_top(int frameX, int frameY) {
			
		int textX;
		int textY;
		g2.setColor(Color.green);	
		
		//title
		String text = "Options";
		textX = getXForCenteredText(text);
		textY = frameY + gp.tileSize;
		g2.drawString(text,  textX,  textY);
		g2.setFont(g2.getFont().deriveFont(25F));  //override the option size
			
		//full screen on/off
		textX = frameX + gp.tileSize;
		textY += gp.tileSize*2;
		g2.drawString("Full Screen", textX, textY);
		if(commandNum == 0) {
			g2.drawImage(gp.player.cursor, 300, 170, 30, 30, null);			//calculated coordiantes by me LOL
			if(gp.keyH.enterPressed == true) {
				if(gp.fullScreenOn == false) {
					gp.fullScreenOn = true; 
				}
				else if(gp.fullScreenOn == true) {
					gp.fullScreenOn = false;
				}
				subState = 1;
			}
		}
		
		//music
		textY += gp.tileSize;
		g2.drawString("Music", textX, textY);
		if(commandNum == 1) {
			g2.drawImage(gp.player.cursor, 300, 220, 30, 30, null);
		}
		//S E
		textY += gp.tileSize;
		g2.drawString("Sound Effects", textX, textY);
		if(commandNum == 2) {
			g2.drawImage(gp.player.cursor, 300, 265, 30, 30, null);
		}
		//control
		textY += gp.tileSize;
		g2.drawString("Control", textX, textY);
		if(commandNum == 3) {
			g2.drawImage(gp.player.cursor, 300, 315, 30, 30, null);
			if(gp.keyH.enterPressed == true) {
				subState = 2;
				commandNum = 0;
			}
		}
		//end game
		textY += gp.tileSize;
		g2.drawString("End Game", textX, textY);
		if(commandNum == 4) {
			g2.drawImage(gp.player.cursor, 300, 365, 30, 30, null);
			if(gp.keyH.enterPressed == true) {
				subState = 3;
				commandNum = 0;
			}
		}
		//Back
		textY += gp.tileSize*2;
		g2.drawString("Back", textX, textY);
		if(commandNum == 5) {
			g2.drawImage(gp.player.cursor, 300, 460, 30, 30, null);
			if(gp.keyH.enterPressed == true) {
				gp.gameState = gp.playState;
				commandNum = 0;
			}
		}
		
		//FULL SCREEN CHECK BOX
		textX = frameX + gp.tileSize*5;
		textY = frameY + gp.tileSize*5/2;
		g2.setStroke(new BasicStroke(3));
		g2.drawRect(textX, textY, 24, 24);
		if(gp.fullScreenOn == true) {
			g2.fillRect(textX, textY, 24, 24);
		}
		
		//music volume
		textY += gp.tileSize;
		g2.drawRect(textX, textY, 120, 24);  // 120/5 = 24pixels
		int volumeWidth = 25 * gp.music.volumeScale;
		g2.fillRect(textX, textY, volumeWidth, 24);
		
		//sound effect
		textY += gp.tileSize;
		g2.drawRect(textX, textY, 120, 24);
		volumeWidth = 25 * gp.se.volumeScale;
		g2.fillRect(textX, textY, volumeWidth, 24);

		gp.config.saveConfig();		//to save current setting
}
	public void option_fullScreenModification(int frameX, int frameY) {
			
		int textX = frameX + gp.tileSize;
		int textY = frameY + gp.tileSize*3;
		g2.setColor(Color.green);
		g2.setFont(g2.getFont().deriveFont(25F)); // only on my screen
		
		currentDialogue = "The change will take \neffect after restarting \nthe game.";
		
		for(String line: currentDialogue.split("\n")) {
			g2.drawString(line, textX, textY);
			textY += 40;
		}
			
		//back
		textY += frameY + gp.tileSize*2; 	//modified back location
		g2.drawString("Back", textX, textY);
		if(commandNum == 0) {
			g2.drawImage(gp.player.cursor, 300, 435, 30, 30, null);	
			if(gp.keyH.enterPressed == true) {	
				subState = 0;
			}
		}
	}	
	public void options_control(int frameX, int frameY) {
		
		int textX;
		int textY;
		
		//title
		String text = "Control";
		textX = getXForCenteredText(text);
		textY = frameY + gp.tileSize;
		g2.drawString(text,  textX,  textY);
		g2.setFont(g2.getFont().deriveFont(20F));  // my modified font size
		g2.setColor(Color.green);
		
		textX = frameX + gp.tileSize;
		textY += gp.tileSize;
		g2.drawString("Move", textX, textY); textY += gp.tileSize;
		g2.drawString("Confirm/Attack", textX, textY); textY += gp.tileSize;
		g2.drawString("Shoot/Cast", textX, textY); textY += gp.tileSize;
		g2.drawString("Character Screen", textX, textY); textY += gp.tileSize;
		g2.drawString("Pause", textX, textY); textY += gp.tileSize;
		g2.drawString("Options", textX, textY); textY += gp.tileSize;
		
		textX = frameX + gp.tileSize*6;
		textY = frameY + gp.tileSize*2;
		g2.drawString("WASD", textX, textY); textY += gp.tileSize;
		g2.drawString("ENTER", textX, textY); textY += gp.tileSize;
		g2.drawString("F", textX, textY); textY += gp.tileSize;
		g2.drawString("C", textX, textY); textY += gp.tileSize;
		g2.drawString("P", textX, textY); textY += gp.tileSize;
		g2.drawString("ESC", textX, textY); textY += gp.tileSize;
		
		//back
		textX = frameX + gp.tileSize;
		textY = frameY + gp.tileSize*9;
		g2.drawString("Back", textX, textY);
		if(commandNum == 0) {
			g2.drawImage(gp.player.cursor, 300, 460, 30, 30, null);	
			if(gp.keyH.enterPressed == true) {
				subState = 0;
				commandNum = 3;
			}
		}
	}
	public void options_endGameConfirmation(int frameX, int frameY) {
		
		int textX = frameX + gp.tileSize;
		int textY = frameY + gp.tileSize*3;
		
		currentDialogue = "Quit the game and \nreturn to the title \nscreen?";
		
		for(String line: currentDialogue.split("\n")) {
			g2.setFont(g2.getFont().deriveFont(20));  // modified font size
			g2.setColor(Color.green);
			g2.drawString(line, textX, textY);
			textY += 40;  	//spacing
		}
		
		//yes
		String text = "Yes";
		textX = getXForCenteredText(text);
		textY += gp.tileSize*5/2;				//yes/no vertical location
		g2.drawString(text, textX, textY);
		if(commandNum == 0) {
			g2.drawImage(gp.player.cursor, 420, 410, 30, 30, null);	
			if(gp.keyH.enterPressed == true) {
				subState = 0;
				gp.gameState = gp.titleState;
				gp.resetGame(true);
				gp.stopMusic();
			}
		}
		//no
		text = "No";
		textX = getXForCenteredText(text);
		textY += gp.tileSize;
		g2.drawString(text, textX, textY);
		if(commandNum == 1) {
			g2.drawImage(gp.player.cursor, 420, 460, 30, 30, null);	
			if(gp.keyH.enterPressed == true) {
				subState = 0;
				commandNum = 4;
			}
		}
	}
	public void drawTransition() {
		
		counter++;
		g2.setColor(new Color(0, 0, 0, counter*5));
		g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);		//entire screen
		
		if(counter == 50) {
			counter = 0;
			gp.gameState = gp.playState;
			gp.currentMap = gp.eHandler.tempMap;
			gp.player.worldX = gp.tileSize * gp.eHandler.tempCol;
			gp.player.worldY = gp.tileSize * gp.eHandler.tempRow;
			gp.eHandler.previousEventX = gp.player.worldX;
			gp.eHandler.previousEventY = gp.player.worldY;
			gp.changeArea();
		}
	}
	public void drawLevelStateScreen() {
		g2.setColor(new Color(0, 0, 0, 150));
		g2.fillRect(0,  0,  gp.screenWidth, gp.screenHeight);
		
		int x;
		int y;
		
		String text;
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 80f));
		
		//shadow
		text = "LEVEL COMPLETED!";
		g2.setColor(Color.white);
		x = getXForCenteredText(text);
		y = gp.tileSize*4;
		g2.drawString(text, x, y);
		
		//main
		g2.setColor(Color.green);
		g2.drawString(text, x-4, y-4);
		
		//ENTER
		g2.setFont(g2.getFont().deriveFont(30f));
		text = "Press Enter to continue";
		x = getXForCenteredText(text);
		y += gp.tileSize * 6;
		g2.drawString(text, x, y);
		
		
	}
	public void drawVictoryStateScreen() {
		
		g2.setColor(new Color(0, 0, 0, 150));
		g2.fillRect(0,  0,  gp.screenWidth, gp.screenHeight);
		
		int x;
		int y;
		
		String text;
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 85f));
		
		//shadow
		text = "CONGRATULATIONS!";
		g2.setColor(Color.white);
		x = getXForCenteredText(text);
		y = gp.tileSize*4;
		g2.drawString(text, x, y);
		
		//main
		g2.setColor(Color.green);
		g2.drawString(text, x-4, y-4);
		
//		//ENTER
//		g2.setFont(g2.getFont().deriveFont(30f));
//		text = "Press Enter to go back";
//		x = getXForCenteredText(text);
//		y += gp.tileSize * 6;
//		g2.drawString(text, x, y);
		
	}
	public void drawDialogueScreen() {	//draw dialogue
		
		//WINDOW
		int x = gp.tileSize*2;
		int y = gp.tileSize/2;
		int width = gp.screenWidth - (gp.tileSize*4);
		int height = gp.tileSize*4;
		
		drawSubWindow(x, y, width, height);
		
		g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 24));	//overriding the default font
		x += gp.tileSize;
		y += gp.tileSize;
		
		for(String line : currentDialogue.split("\n")) {	//split the text in dialogue using /n
			g2.drawString(line, x, y);
			y += 40;
		}
	}
	public void drawSubWindow(int x, int y, int width, int height) {	//drawing sub window (inventory)
		
		Color c = new Color(0, 0, 0, 210);
		g2.setColor(c);
		g2.fillRoundRect(x, y, width, height, 40, 40);		//roundness of a rectangle
		
		c = new Color(255, 255, 255);		//RGP For white
		g2.setColor(c);
		g2.setStroke(new BasicStroke(5));	//outline of roundRect
		g2.drawRoundRect(x + 5, y + 5, width-10, height-10, 25, 25);
		
	}
	public int getXForCenteredText(String text) {	//centering the x position on screen
		
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		
		return x;
	}
	public int getXForAlignToRightText(String text, int tailX) {	//aligning to right x position on screen	(eg. press the c then the value of player status is aligned	
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = tailX - length;
		
		return x;
	}
}
