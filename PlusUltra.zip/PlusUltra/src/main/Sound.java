package main;

import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class Sound {

	Clip clip;			 //to open audio file
	URL soundURL[] = new URL[25]; 		//store the sound file
	FloatControl fc;	//option state, change volume
	int volumeScale = 3;
	float volume;
	
	public Sound() {
		
		soundURL[0] = getClass().getResource("/sound/plusultra.wav");
		soundURL[1] = getClass().getResource("/sound/coin.wav");
		soundURL[2] = getClass().getResource("/sound/door.wav");
		soundURL[3] = getClass().getResource("/sound/energy.wav");
		soundURL[4] = getClass().getResource("/sound/durara.wav");
		soundURL[5] = getClass().getResource("/sound/elegance.wav");
		soundURL[6] = getClass().getResource("/sound/ginko.wav");
		soundURL[7] = getClass().getResource("/sound/goldetime.wav");
		soundURL[8] = getClass().getResource("/sound/hit.wav");
		soundURL[9] = getClass().getResource("/sound/hunter.wav");
		soundURL[10] = getClass().getResource("/sound/punch.wav");
		soundURL[11] = getClass().getResource("/sound/kiss.wav");
		soundURL[12] = getClass().getResource("/sound/lovelies.wav");
		soundURL[13] = getClass().getResource("/sound/punchW.wav");
		soundURL[14] = getClass().getResource("/sound/punchair.wav");
		soundURL[15] = getClass().getResource("/sound/punched.wav");
//		soundURL[16] = getClass().getResource("/sound/rezro.wav");
		soundURL[17] = getClass().getResource("/sound/tada.wav");
		soundURL[18] = getClass().getResource("/sound/tempfanfare.wav");
		soundURL[19] = getClass().getResource("/sound/clicks.wav");
		soundURL[20] = getClass().getResource("/sound/fire.wav");
		soundURL[21] = getClass().getResource("/sound/goldenTime.wav");
		soundURL[22] = getClass().getResource("/sound/unlock.wav");
		soundURL[23] = getClass().getResource("/sound/unlock.wav");
	}
	
	public void setFile(int i) {
		
		try {
			
			AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
			clip = AudioSystem.getClip();
			clip.open(ais);
			fc = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
			checkVolume();
			
		}catch(Exception e) {
			
		}
	}
	public void play() {
		
		clip.start();
	}
	public void loop() {
		
		clip.loop(clip.LOOP_CONTINUOUSLY);
	}
	public void stop() {
		
		clip.stop();
	}
	public void checkVolume() {		//to adjust volume in option state
		
		switch(volumeScale) {
		case 0: volume = -80f; break;
		case 1: volume = -20f; break;
		case 2: volume = -12f; break;
		case 3: volume = -5f; break;
		case 4: volume = 1f; break;
		case 5: volume = 6f; break;
		}
		fc.setValue(volume);
	}
}
