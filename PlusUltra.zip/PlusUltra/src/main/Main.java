package main;

import javax.swing.JFrame;

public class Main {

	public static JFrame frame;
	
	public static void main(String[] args) {
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	//to close window properly
		frame.setResizable(false);				//can't be resized
		frame.setTitle("Plus Ultra");		//title
//		frame.setUndecorated(true);			//part of full screen function
//		byt the  config seems to soleved the issue		
		GamePanel gamePanel = new GamePanel();
		frame.add(gamePanel);
		
		gamePanel.config.loadConfig();
		if(gamePanel.fullScreenOn == true) {	//load the settings(save)
			frame.setUndecorated(true);
		}
		
		frame.pack();				//to see the screen
		
		frame.setLocationRelativeTo(null);		//window center of the screen
		frame.setVisible(true); 			//to show the window
		
		gamePanel.setUpGame();
		gamePanel.startGameThread();
		
	}
}

//make portal as a tile not object
//use the knockBack to trap awakened shogaraki
//create a damagepit event in black tile
//play 21 goldenTime if player win
//change the cursor sound
//change the cursor in option state
//player can't talk npc by pressing enter alone (need to prees move keys along)'
//knockback the enemie using damage Reaction method and get into the crossing path dont need to kill them