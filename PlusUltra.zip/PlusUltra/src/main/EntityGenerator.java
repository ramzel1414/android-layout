package main;

import entity.Entity;
import object.OBJ_Bomb;
import object.OBJ_Chest;
import object.OBJ_Door;
import object.OBJ_Energy;
import object.OBJ_Energy2;
import object.OBJ_Fist;
import object.OBJ_Gloves;
import object.OBJ_Heart;
import object.OBJ_Key;
import object.OBJ_Kiss;
import object.OBJ_Mines;

public class EntityGenerator {

	GamePanel gp;
	
	public EntityGenerator(GamePanel gp) {
		this.gp = gp;
	}
	public Entity getObject(String itemName) {
		
		Entity obj = null;
		
		switch(itemName) {
		case OBJ_Bomb.objName: obj = new OBJ_Bomb(gp); break;
		case OBJ_Chest.objName: obj = new OBJ_Chest(gp); break;
		case OBJ_Door.objName: obj = new OBJ_Door(gp); break;
		case OBJ_Energy.objName: obj = new OBJ_Energy(gp); break;
		case OBJ_Energy2.objName: obj = new OBJ_Energy2(gp); break;
		case OBJ_Fist.objName: obj = new OBJ_Fist(gp); break;
		case OBJ_Gloves.objName: obj = new OBJ_Gloves(gp); break;
		case OBJ_Heart.objName: obj = new OBJ_Heart(gp); break;
		case OBJ_Key.objName: obj = new OBJ_Key(gp); break;
		case OBJ_Kiss.objName: obj = new OBJ_Kiss(gp); break;
		case OBJ_Mines.objName: obj = new OBJ_Mines(gp); break;
		}
		return obj;
	}
}
