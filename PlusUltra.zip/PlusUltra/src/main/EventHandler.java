package main;


public class EventHandler {

	GamePanel gp;
	EventRect eventRect[][][];
	
	int previousEventX, previousEventY;
	boolean canTouchEvent = true;
	int tempMap, tempCol, tempRow;
	
	public EventHandler(GamePanel gp) {
		this.gp = gp;
		
		eventRect = new EventRect[gp.maxMap][gp.maxWorldCol][gp.maxWorldRow];
		
		int map = 0;
		int col = 0;
		int row = 0;
		while(map < gp.maxMap && col < gp.maxWorldCol && row < gp.maxWorldRow) {
			
			eventRect[map][col][row] = new EventRect();
			eventRect[map][col][row].x = 23;
			eventRect[map][col][row].y = 32;
			eventRect[map][col][row].width = 2;
			eventRect[map][col][row].height = 2;
			eventRect[map][col][row].eventRectDefaultX = eventRect[map][col][row].x;
			eventRect[map][col][row].eventRectDefaultY = eventRect[map][col][row].y;
			
			col++;
			if(col == gp.maxWorldCol) {
				col = 0;
				row++;
				
				if(row == gp.maxWorldRow) {		//reset rectangle in each map
					row = 0;
					map++;
				}
			}
		}
		
	}
	
	public void checkEvent() {		//checks the event

		//check if the player is more than one tile away from the event
		int xDistance = Math.abs(gp.player.worldX - previousEventX);
		int yDistance = Math.abs(gp.player.worldY - previousEventY);
		int distance = Math.max(xDistance, yDistance);
		if(distance > gp.tileSize) {
			
			
			canTouchEvent = true;
		}
		if(canTouchEvent == true) {		//really effecient in teleport event
			
			if(hit(3, 12, 9, "any") == true) { saveLoadPit(3, 12, 9, gp.dialogueState);}
			else if(hit(1, 28, 30, "any") == true) { levelPit(gp.levelState, 1, 28, 30);}
			else if(hit(2, 38, 45, "any") == true) { levelPit(gp.levelState, 2, 38, 45);}
			else if(hit(3, 24, 6, "any") == true) { levelPit(gp.levelState, 3, 24, 6);}
			else if(hit(4, 26, 30, "any") == true) { levelPit(gp.levelState, 4, 26, 30);}
			else if(hit(5, 11, 13, "any") == true) { levelPit(gp.levelState, 5, 11, 13);}
			else if(hit(6, 40, 4, "any") == true) { victoryPit(gp.victoryState, 6, 40, 4);}		//temporary 
			
			else if(hit(1, 28, 31, "any") == true) { teleportMap(2, 38, 5, gp.indoor);}
			else if(hit(2, 38, 5, "any") == true) { teleportMap(1, 28, 31, gp.indoor);}
			else if(hit(2, 38, 46, "any") == true) { teleportMap(3, 9, 5, gp.indoor);}
			else if(hit(3, 9, 5, "any") == true) { teleportMap(2, 38, 46, gp.indoor);}
			else if(hit(3, 22, 5, "any") == true) { teleportMap(4, 21, 31,gp.dungeon);}
			else if(hit(4, 21, 31, "any") == true) { teleportMap(3, 22, 5, gp.indoor);}
			else if(hit(4, 26, 31, "any") == true) { teleportMap(5, 4, 4, gp.indoor);}
			else if(hit(5, 4, 4, "any") == true) { teleportMap(4, 26, 31, gp.dungeon);}
			else if(hit(5, 11, 12, "any") == true) { teleportMap(6, 8, 45, gp.indoor);}
			else if(hit(6, 8, 45, "any") == true) { teleportMap(5, 11, 12, gp.indoor);}
			else if(hit(6, 19, 38, "any") == true) { teleportMap(2, 25, 8, gp.indoor);}
			else if(hit(2, 25, 8, "any") == true) { teleportMap(6, 19, 38, gp.indoor);}
		}
	}
	
	public boolean hit(int map, int col, int row, String reqDirection) {		//checks event collision
		
		boolean hit = false;
		
		if(map == gp.currentMap) {
			
			gp.player.solidArea.x = gp.player.worldX + gp.player.solidArea.x;
			gp.player.solidArea.y = gp.player.worldY + gp.player.solidArea.y;
			eventRect[map][col][row].x = col*gp.tileSize+eventRect[map][col][row].x;
			eventRect[map][col][row].y = row*gp.tileSize+eventRect[map][col][row].y;
			
			if(gp.player.solidArea.intersects(eventRect[map][col][row]) && eventRect[map][col][row].eventDone == false) {
				if(gp.player.direction.contentEquals(reqDirection) || reqDirection.contentEquals("any")) {
					hit = true;
				
					previousEventX = gp.player.worldX;
					previousEventY = gp.player.worldY;
				}
			}
			
			gp.player.solidArea.x = gp.player.solidAreaDefaultX;
			gp.player.solidArea.y = gp.player.solidAreaDefaultY;
			eventRect[map][col][row].x = eventRect[map][col][row].eventRectDefaultX;
			eventRect[map][col][row].y = eventRect[map][col][row].eventRectDefaultY;
			
		}
		return hit;
	}
	public void saveLoadPit(int map, int col, int row, int gameState) {
		
		eventRect[map][col][row].eventDone = true;
		gp.gameState = gameState;
		gp.playSE(11);
		gp.ui.currentDialogue = "Game has been saved!";
		gp.player.life += 1;
		gp.saveLoad.save();
	}
	public void healingPool(int gameState) {
		
		if(gp.keyH.enterPressed == true) {
			gp.player.attackCanceled = true;
			gp.gameState = gameState;
			gp.ui.currentDialogue = "You drink the water of life.";
			gp.player.life = gp.player.maxLife;
			gp.aSetter.setMonster();		//if you drink water monster will respawn
			
		}
	}
	public void teleport(int col, int row, int gameState) {
		
		gp.gameState = gameState;
		gp.playSE(9);
		gp.ui.currentDialogue = "Teleport!";
		gp.player.worldX = gp.tileSize*25;
		gp.player.worldY = gp.tileSize*7;
		
	}

	public void teleport2(int col, int row, int gameState) {
		
		gp.gameState = gameState;
		gp.playSE(9);
		gp.ui.currentDialogue = "Teleport";
		gp.player.worldX = gp.tileSize*23;
		gp.player.worldY = gp.tileSize*9;
	}
	public void teleportMap(int map, int col, int row, int area) {
		
		gp.gameState = gp.transitionState;
		gp.nextArea = area;
		tempMap = map;
		tempCol = col;
		tempRow = row;
		canTouchEvent = false;
		gp.playSE(9);
	}
	public void levelPit(int gameState, int map, int col, int row) {
		
		eventRect[map][col][row].eventDone = true;
		gp.gameState = gameState;
		gp.playSE(7);

		
	}
	public void victoryPit(int gameState, int map, int col, int row) {
		
		eventRect[map][col][row].eventDone = true;
		gp.gameState = gameState;
		gp.playSE(21);

		
	}
}
