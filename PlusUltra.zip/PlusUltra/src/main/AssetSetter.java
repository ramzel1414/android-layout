package main;

import entity.NPC_GranTorino;
import monster.MON_Awakened;
import monster.MON_Car;
import monster.MON_CarRed;
import monster.MON_Nomu;
import monster.MON_Shigaraki;
import object.OBJ_Bulb;
import object.OBJ_Chest;
import object.OBJ_Door;
import object.OBJ_Energy;
import object.OBJ_Energy2;
import object.OBJ_Gloves;
import object.OBJ_Heart;
import object.OBJ_Key;
import object.OBJ_Kiss;
import tile_interactive.IT_Wall;

public class AssetSetter {

	GamePanel gp;
	
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
		
	}
	
	public void setObject() {	//instantiate object and place to map
		
		//just change this to 0 later
		int mapNum = 1;			//to place of entity in different maps
		int i = 0;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize * 29;
		gp.obj[mapNum][i].worldY = gp.tileSize * 18;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize * 20;
		gp.obj[mapNum][i].worldY = gp.tileSize * 29;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize * 27;
		gp.obj[mapNum][i].worldY = gp.tileSize * 29;
		i++;
		
		
		
		mapNum = 2;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 37 * gp.tileSize;	     //top
		gp.obj[mapNum][i].worldY = 10 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 36 * gp.tileSize;	     //below 
		gp.obj[mapNum][i].worldY = 36 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 36 * gp.tileSize;	     //below below
		gp.obj[mapNum][i].worldY = 39 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 34 * gp.tileSize;	     //below below
		gp.obj[mapNum][i].worldY = 39 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 6 * gp.tileSize;	     //below left
		gp.obj[mapNum][i].worldY = 10 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 27 * gp.tileSize;	     //top in wall
		gp.obj[mapNum][i].worldY = 11 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Energy2(gp);
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;	     //
		gp.obj[mapNum][i].worldY = 39 * gp.tileSize;
		i++;
		
		
		
		mapNum = 3;
		
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 21 * gp.tileSize;	//top right
		gp.obj[mapNum][i].worldY = 10 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 10 * gp.tileSize;	//down left
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;

		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 23 * gp.tileSize;		//above right
		gp.obj[mapNum][i].worldY = 11 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 15 * gp.tileSize;	//above player
		gp.obj[mapNum][i].worldY = 9 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 19 * gp.tileSize;		//inside wall
		gp.obj[mapNum][i].worldY = 7 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 18 * gp.tileSize;		//inside wall
		gp.obj[mapNum][i].worldY = 7 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 17 * gp.tileSize;		//inside wall
		gp.obj[mapNum][i].worldY = 7 * gp.tileSize;
		i++;

		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 25 * gp.tileSize;		//monster carRed 
		gp.obj[mapNum][i].worldY = 28 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Bulb(gp);
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;	//corner of map
		gp.obj[mapNum][i].worldY = 41 * gp.tileSize;
		i++;
		
		
		gp.obj[mapNum][i] = new OBJ_Heart(gp);
		gp.obj[mapNum][i].worldX = 38 * gp.tileSize;	//corner of map
		gp.obj[mapNum][i].worldY = 41 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Kiss(gp);
		gp.obj[mapNum][i].worldX = 8 * gp.tileSize;	//corner of map
		gp.obj[mapNum][i].worldY = 42 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Kiss(gp);
		gp.obj[mapNum][i].worldX = 9 * gp.tileSize;	//corner of map
		gp.obj[mapNum][i].worldY = 42 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Kiss(gp);
		gp.obj[mapNum][i].worldX = 10 * gp.tileSize;	//corner of map
		gp.obj[mapNum][i].worldY = 42 * gp.tileSize;
		i++;
	
		gp.obj[mapNum][i] = new OBJ_Gloves(gp);
		gp.obj[mapNum][i].worldX = 36 * gp.tileSize;
		gp.obj[mapNum][i].worldY = 42 * gp.tileSize;
		i++;
		
		
		gp.obj[mapNum][i] = new OBJ_Energy2(gp);
		gp.obj[mapNum][i].worldX = 9 * gp.tileSize;	     //below left
		gp.obj[mapNum][i].worldY = 17 * gp.tileSize;
		i++;

		gp.obj[mapNum][i] = new OBJ_Heart(gp);
		gp.obj[mapNum][i].worldX = 9 * gp.tileSize;	     //below left
		gp.obj[mapNum][i].worldY = 18 * gp.tileSize;
		i++;
		
		
		
		
		mapNum = 4;
//		gp.obj[mapNum][i] = new OBJ_Gloves(gp);
//		gp.obj[mapNum][i].worldX = 1 * gp.tileSize;
//		gp.obj[mapNum][i].worldY = 48 * gp.tileSize;
//		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = 1 * gp.tileSize;
		gp.obj[mapNum][i].worldY = 48 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 2 * gp.tileSize;
		gp.obj[mapNum][i].worldY = 46 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);				//from world 3
		gp.obj[mapNum][i].worldX = 21 * gp.tileSize;
		gp.obj[mapNum][i].worldY = 28 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);
		gp.obj[mapNum][i].worldX = 26 * gp.tileSize;		//to world 5
		gp.obj[mapNum][i].worldY = 28 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 15 * gp.tileSize;		//top
		gp.obj[mapNum][i].worldY = 8 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 1 * gp.tileSize;		//top corner
		gp.obj[mapNum][i].worldY = 1 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 34 * gp.tileSize;		//bottom  right
		gp.obj[mapNum][i].worldY = 36 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 1 * gp.tileSize;		//bottom  right
		gp.obj[mapNum][i].worldY = 26 * gp.tileSize;
		i++;
		
		
		mapNum = 5;
//		gp.obj[mapNum][i] = new OBJ_Heart(gp);			//nomu guard
//		gp.obj[mapNum][i].worldX = 32 * gp.tileSize;	    
//		gp.obj[mapNum][i].worldY = 10 * gp.tileSize;
//		i++;
														//nomu is the key
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 26 * gp.tileSize;		//top corner
		gp.obj[mapNum][i].worldY = 13 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 11 * gp.tileSize;		//top corner
		gp.obj[mapNum][i].worldY = 14 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 14 * gp.tileSize;		//top corner
		gp.obj[mapNum][i].worldY = 14 * gp.tileSize;
		i++;
		
		
		
		mapNum = 6;
		
		gp.obj[mapNum][i] = new OBJ_Energy2(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		
		gp.obj[mapNum][i].worldY = 24 * gp.tileSize;
		i++;		
		gp.obj[mapNum][i] = new OBJ_Energy2(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		
		gp.obj[mapNum][i].worldY = 25 * gp.tileSize;
		i++;	
		gp.obj[mapNum][i] = new OBJ_Energy2(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		
		gp.obj[mapNum][i].worldY = 26 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 11 * gp.tileSize;		//first
		gp.obj[mapNum][i].worldY = 36 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 11 * gp.tileSize;		//second
		gp.obj[mapNum][i].worldY = 31 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 11 * gp.tileSize;		//third
		gp.obj[mapNum][i].worldY = 20 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 11 * gp.tileSize;		//last
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;
		
		
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 22 * gp.tileSize;		//chase
		gp.obj[mapNum][i].worldY = 38 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 23 * gp.tileSize;		//below chase
		gp.obj[mapNum][i].worldY = 41 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//1
		gp.obj[mapNum][i].worldY = 39 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//2
		gp.obj[mapNum][i].worldY = 37 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//3
		gp.obj[mapNum][i].worldY = 35 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//4
		gp.obj[mapNum][i].worldY = 33 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//5
		gp.obj[mapNum][i].worldY = 32 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//5
		gp.obj[mapNum][i].worldY = 31 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Door(gp);						
		gp.obj[mapNum][i].worldX = 39 * gp.tileSize;		//5
		gp.obj[mapNum][i].worldY = 30 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		//left
		gp.obj[mapNum][i].worldY = 14 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		//left
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 8 * gp.tileSize;		//left
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 7 * gp.tileSize;		//left
		gp.obj[mapNum][i].worldY = 13 * gp.tileSize;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 15 * gp.tileSize;		//right
		gp.obj[mapNum][i].worldY = 14 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 15 * gp.tileSize;		//rifht
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 14 * gp.tileSize;		//right
		gp.obj[mapNum][i].worldY = 15 * gp.tileSize;
		i++;
		gp.obj[mapNum][i] = new OBJ_Key(gp);						
		gp.obj[mapNum][i].worldX = 15 * gp.tileSize;		//right
		gp.obj[mapNum][i].worldY = 13 * gp.tileSize;
		i++;
		
//		gp.obj[mapNum][i] = new OBJ_Gloves(gp);						
//		gp.obj[mapNum][i].worldX = 20 * gp.tileSize;		//right
//		gp.obj[mapNum][i].worldY = 13 * gp.tileSize;
//		i++;
		
	}
	public void setNPC() {
		
		int mapNum = 1;
		int i = 0;
		
		mapNum = 3;
		gp.npc[mapNum][i] = new NPC_GranTorino(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize * 22;
		gp.npc[mapNum][i].worldY = gp.tileSize * 16;
		i++;
		
		
		mapNum = 6;
		gp.npc[mapNum][i] = new NPC_GranTorino(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize * 14;
		gp.npc[mapNum][i].worldY = gp.tileSize * 39;
		i++;
	
	}
	public void setMonster() {
		
		int mapNum = 1;
		int i = 0;
		
		
		mapNum = 2;
		gp.monster[mapNum][i] = new MON_Shigaraki(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 35;
		gp.monster[mapNum][i].worldY = gp.tileSize * 38;
		i++;
		
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 29;
		gp.monster[mapNum][i].worldY = gp.tileSize * 11;
		i++;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 30;
		gp.monster[mapNum][i].worldY = gp.tileSize * 11;
		i++;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 31;
		gp.monster[mapNum][i].worldY = gp.tileSize * 12;
		i++;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 32;
		gp.monster[mapNum][i].worldY = gp.tileSize * 13;
		i++;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 33;
		gp.monster[mapNum][i].worldY = gp.tileSize * 13;
		i++;
		
		
		mapNum = 3;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 11;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 13;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 15;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 17;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 21;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 22;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 23;
		gp.monster[mapNum][i].worldY = gp.tileSize * 22;
		i++;
		
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 13;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 14;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 17;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);			//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 18;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 21;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 22;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 25;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 26;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 29;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 30;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 33;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 34;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 35;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 36;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 37;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 38;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 39;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 40;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		gp.monster[mapNum][i] = new MON_CarRed(gp);				//below
		gp.monster[mapNum][i].worldX = gp.tileSize * 41;
		gp.monster[mapNum][i].worldY = gp.tileSize * 30;
		i++;
		
		
		
		
		mapNum = 4;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 5;
		gp.monster[mapNum][i].worldY = gp.tileSize * 36;
		i++;
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 5;
		gp.monster[mapNum][i].worldY = gp.tileSize * 47;
		i++;
		
		
		
		mapNum = 5;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 8;		
		gp.monster[mapNum][i].worldY = gp.tileSize * 5;
		i++;
		
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;	//first highway
		gp.monster[mapNum][i].worldY = gp.tileSize * 14;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 16;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 17;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 19;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 21;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 23;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 25;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 27;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 29;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 31;

		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 33;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 34;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 35;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 37;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 20;
		gp.monster[mapNum][i].worldY = gp.tileSize * 38;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 39;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 40;
		i++;
		gp.monster[mapNum][i] = new MON_Car(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 19;
		gp.monster[mapNum][i].worldY = gp.tileSize * 42;
		i++;
		
		gp.monster[mapNum][i] = new MON_Nomu(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 27;
		gp.monster[mapNum][i].worldY = gp.tileSize * 13;
		i++;

		
		
		
		mapNum = 6;
		
		gp.monster[mapNum][i] = new MON_Shigaraki(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 11;
		gp.monster[mapNum][i].worldY = gp.tileSize * 40;
		i++;
		gp.monster[mapNum][i] = new MON_Shigaraki(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 12;
		gp.monster[mapNum][i].worldY = gp.tileSize * 26;
		i++;
		gp.monster[mapNum][i] = new MON_Shigaraki(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 11;
		gp.monster[mapNum][i].worldY = gp.tileSize * 28;
		i++;
		
		gp.monster[mapNum][i] = new MON_Awakened(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize * 10;
		gp.monster[mapNum][i].worldY = gp.tileSize * 10;
		i++;
		
		
		
	}
	public void setInteractiveTile() {
		
		int mapNum = 1;
		int i = 0;
		
		gp.iTile[mapNum][i] = new IT_Wall(gp, 21, 29);		//beside key
		i++;
				
		mapNum = 2;
		gp.iTile[mapNum][i] = new IT_Wall(gp, 26, 11);		//beside key
		i++;
		
		mapNum = 3;
		gp.iTile[mapNum][i] = new IT_Wall(gp, 19, 8);		//below bulb
		i++;
		mapNum = 3;
		gp.iTile[mapNum][i] = new IT_Wall(gp, 37, 42);		//beside key
		i++;
		mapNum = 4;
//		gp.iTile[mapNum][i] = new IT_Wall(gp, 26, 29);		//behind door 
		i++;
	}
}
