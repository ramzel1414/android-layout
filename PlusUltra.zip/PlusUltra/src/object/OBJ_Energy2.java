package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Energy2 extends Entity{

	GamePanel gp;	
	
	public static final String objName = "Speed Controller";
	
	public OBJ_Energy2(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_consumable;
		name = objName;
		value = 4;
		down1 = setup("/objects/energy2", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nControlls your speed.";
	}
	
	public boolean use(Entity entity) {
		
		gp.playSE(3);
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You just used an " + name + "!\n" 
				+ "Your speed has decreased by 2x.";
		entity.speed /= 2;
		
		//play shound
		return true;	
	}
}