package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Kiss extends Entity{

	GamePanel gp;
	
	public static final String objName = "Recovery Kiss";
	
	public OBJ_Kiss(GamePanel gp) {
		super(gp);
		
		this.gp = gp;
		
		type = type_consumable;
		name = objName;
		value = 4;
		down1 = setup("/objects/kiss", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nRecovers your life with love";
		
	}
	public boolean use(Entity entity) {
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You just used Recovery Girl's Kiss!\n" 
				+ "Your life has been recovered by " + value + ".";
		entity.life += value;
		
		gp.playSE(11);
		return true;
	}
}
