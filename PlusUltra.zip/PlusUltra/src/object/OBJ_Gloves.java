package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Gloves extends Entity{

	public static final String objName = "PlusUltra Gloves";
	
	public OBJ_Gloves(GamePanel gp) {
		super(gp);
		
		
		type = type_gloves;
		name = objName;
		down1 = setup("/objects/glove", gp.tileSize, gp.tileSize);
		attackValue = 1;	//this doesnt matter (maybe?)
		attackArea.width = 36;
		attackArea.height = 36;
		description = "[" + name + "]\nCan Smash a weak Wall!.";
		knockBackPower = 0;
		

	}
}
