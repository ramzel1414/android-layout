package object;

import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_Key extends Entity{

	GamePanel gp;	
	
	public static final String objName = "Key";
	
	public OBJ_Key(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_consumable;
		name = objName;
		down1 = setup("/objects/key", gp.tileSize, gp.tileSize);
		image = setup("/objects/key", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nA key that can open an\niron door.";
		
		
	}
	public boolean use(Entity entity) {	//use of the key override use method
		
		gp.gameState = gp.dialogueState;
		
		int objIndex = getDetected(entity, gp.obj, "Door");
		
		if(objIndex != 999) {
			gp.ui.currentDialogue = "The door has been unlocked!";
			gp.playSE(22);
			gp.obj[gp.currentMap][objIndex] = null;
			return true;
		}
		else {
			gp.ui.currentDialogue = "Find a door!";
			return false;
		}
		
	}
}
