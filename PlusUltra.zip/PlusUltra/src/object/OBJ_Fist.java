package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Fist extends Entity{

		
	public static final String objName = "Fist";
	
	public OBJ_Fist(GamePanel gp) {
		super(gp);
		
		type = type_fist;
		name = objName;
		down1 = setup("/objects/fist", gp.tileSize, gp.tileSize);
		attackValue = 1;	//this doesnt matter (maybe?)
		attackArea.width = 18;
		attackArea.height = 18;
		description = "[" + name + "]\nPlus Ultra!.";
		knockBackPower = 0;
		

	}
}
