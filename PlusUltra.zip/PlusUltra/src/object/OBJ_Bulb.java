package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Bulb extends Entity{

	GamePanel gp;	
	
	public static final String objName = "Bulb";
	
	public OBJ_Bulb(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_light;
		name = objName;
		down1 = setup("/objects/bulb", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nObject that can see darkness.";
		lightRadius = 250;
	}
	

}
