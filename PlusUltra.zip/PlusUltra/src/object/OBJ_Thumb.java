package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Thumb extends Entity{

	GamePanel gp;	
	
	public static final String objName = "Thumb's up";
	
	public OBJ_Thumb(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_consumable;
		name = objName;
		down1 = setup("/objects/thumb", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nShigaraki's message.";
	}
	public boolean use(Entity entity) {
		
		gp.playSE(3);
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You just got Shigaraki's " + name + "!\n" 
				+ "You can now go outside!.";
		entity.speed *= 2;
		
		//play shound
		return true;
	}

}