package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Door extends Entity{

	GamePanel gp;

	public static final String objName = "Door";
	
	public OBJ_Door(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_obstacle;
		name = objName;
		image = setup("/objects/doorclosed", gp.tileSize, gp.tileSize);
		image2 = setup("/objects/dooropened", gp.tileSize, gp.tileSize);
		down1 = image;
		collision = true;
		description = "[" + name + "]\nA door made of polished\niron.";
		
	}
	public void interact() {
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You need a key!";
		
		down1 = image2;
		
	}
}
