package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Energy extends Entity{

	GamePanel gp;	
	
	public static final String objName = "Energy";
	
	public OBJ_Energy(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_consumable;
		name = objName;
//		speed = 2;
		down1 = setup("/objects/energy", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\nRun at lightning speed.";
	}
	
	public boolean use(Entity entity) {
		
		gp.playSE(3);
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You just used an " + name + "!\n" 
				+ "Your speed has increased by 2x.";
		entity.speed *= 2;
		
		//play shound
		return true;
	}
}
