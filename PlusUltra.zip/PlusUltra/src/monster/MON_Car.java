package monster;

import java.util.Random;

import entity.Entity;
import main.GamePanel;
import object.OBJ_Energy;
import object.OBJ_Energy2;
import object.OBJ_Heart;
import object.OBJ_Key;
import object.OBJ_Mines;

public class MON_Car extends Entity{

	GamePanel gp;
	
	public MON_Car(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		direction = "right";
		type = type_monster;
		name = "Violet Car";
		defaultSpeed = 3;
		speed = defaultSpeed;
		maxLife = 6;
		life = maxLife;
		attack = 2;
		defense = 0;
		exp = 3;
		projectile = new OBJ_Mines(gp);
		
		solidArea.x = 3;
		solidArea.y = 5;
		solidArea.width = 42;
		solidArea.height = 40;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
		
	}
	public void getImage() {	//image of car
		
		up1 = setup("/monster/car_up_1", gp.tileSize, gp.tileSize);
		up2 = setup("/monster/car_up_2", gp.tileSize, gp.tileSize);
		down1 = setup("/monster/car_down_1", gp.tileSize, gp.tileSize);
		down2 = setup("/monster/car_down_2", gp.tileSize, gp.tileSize);
		left1 = setup("/monster/car_left_1", gp.tileSize, gp.tileSize);
		left2 = setup("/monster/car_left_2", gp.tileSize, gp.tileSize);
		right1 = setup("/monster/car_right_1", gp.tileSize, gp.tileSize);
		right2 = setup("/monster/car_right_2", gp.tileSize, gp.tileSize);
		
	}
	public void setAction() {	//behavior of car
		
		actionLockCounter++;
		
		if(actionLockCounter == 120) {		//control movement to every 2 seconds
											//randomly picks directionn
			Random random = new Random();
			
			int i = random.nextInt(100) + 1;	//picks random # 1=100
			
			if(i <= 0) {						//5% move up, down, 45% move right, and left
				direction = "up";
			}
			if(i > 0 && i <= 0) {
				direction = "down";
			}
			if(i > 0 && i <= 50) {
				direction = "left";
			}
			if(i > 50 && i <= 100) {
				direction = "right";
			}
			actionLockCounter = 0;
			
		}
		//MONSTER SHOOT RANDOMLY
		int i = new Random().nextInt(100) + 1;
		if(i > 99 && projectile.alive == false && shotAvailableCounter == 30) {
			projectile.set(worldX, worldY, direction, true, this);
			
			//CHECK VACANCY
			for(int ii = 0; ii < gp.projectile[1].length; ii++) {
				if(gp.projectile[gp.currentMap][ii] == null) {
					gp.projectile[gp.currentMap][ii] = projectile;
					break;
					
				}
			}
			
			shotAvailableCounter = 0;
		}
	}
	
//	//ACTIVATE THIS METHOD IF YOU WANT MONSTER TO BE ELUSIVE(MAILAP)
//	//galagpot kung sumbagon LOL
//	public void damageReaction() {	//mosnter reaction when get attacked
//		
//		actionLockCounter = 0;
//		direction = gp.player.direction;	//move away to the direction where it gets hit
//		speed += 2;
//	}
	public void checkDrop() {		//when mosnter dies		WHAT ITEM TO DROP
		
		int i = new Random().nextInt(100)+1;	//case a die
		
		//SET MOSNTER DROP		
		if(i < 5) {
			dropItem(new OBJ_Key(gp));
		}
		if(i >= 50 && i < 75) {
			dropItem(new OBJ_Heart(gp));
		}
//		if(i >= 75 && i < 100) {
//			dropItem(new OBJ_Energy2(gp));
//		}
		
	}
}
